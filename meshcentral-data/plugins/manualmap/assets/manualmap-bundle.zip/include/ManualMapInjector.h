#pragma once

#include <Windows.h>
#include <string>
#include <vector>

namespace injection {

enum ManualMapFlags : DWORD {
    kManualMapHideFromPeb = 0x01,
    kManualMapEraseHeaders = 0x02,
    kManualMapFakeHeader = 0x04,
    kManualMapUnlinkFromVad = 0x08,
    kManualMapNoExceptions = 0x10
};

class ManualMapInjector {
public:
    ManualMapInjector();

    bool LoadFromFile(const std::wstring& dllPath);
    bool LoadFromMemory(const BYTE* buffer, size_t size);

    bool InjectIntoProcess(DWORD processId, DWORD flags = 0);
    bool InjectIntoProcess(HANDLE processHandle, DWORD flags = 0);

    const std::wstring& GetLastError() const noexcept { return lastError_; }
    size_t ImageSize() const noexcept { return dllBuffer_.size(); }

private:
    bool ValidatePE();
    bool PerformManualMap(HANDLE process, DWORD flags);
    bool CopySections(HANDLE process, LPVOID targetBase);
    bool ProcessRelocations(HANDLE process, LPVOID targetBase);
    bool ResolveImports(HANDLE process, LPVOID targetBase);
    bool AdjustProtections(HANDLE process, LPVOID targetBase);
    bool ExecuteTLSCallbacks(HANDLE process, LPVOID targetBase);
    bool CallDllMain(HANDLE process, LPVOID targetBase, DWORD fdwReason);
    void EraseHeaders(HANDLE process, LPVOID targetBase);
    void HideFromPEB(HANDLE process, LPVOID targetBase);
    void UnlinkFromVAD(HANDLE process, LPVOID targetBase);
    void SetLastErrorMessage(const std::wstring& message);
    void SetLastErrorFromWin32(const wchar_t* context);
    BYTE* RvaToPointer(DWORD rva);

    std::vector<BYTE> dllBuffer_;
    PIMAGE_NT_HEADERS ntHeaders_;
    PIMAGE_DOS_HEADER dosHeader_;
    std::wstring lastError_;
};

}  // namespace injection
