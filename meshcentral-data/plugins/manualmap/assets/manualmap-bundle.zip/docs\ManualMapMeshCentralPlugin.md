# ManualMap MeshCentral Plugin

This document summarizes how to install and operate the ManualMap deployment plugin that lives in `meshcentral-plugin/manualmap`.

## Prerequisites

- MeshCentral `config.json` must have plugins enabled:

  ```json
  "plugins": {
      "enabled": true
  }
  ```

- The ManualMap harness build artifacts must be collected into a single archive (default: `manualmap-bundle.zip`).
- Administrative access to the MeshCentral server and the target device group.

## Packaging Assets

1. Run the usual build flow for the harness (for example `build_advanced.bat`).
2. Package the deployment archive via PowerShell:

   ```powershell
   powershell.exe -ExecutionPolicy Bypass -File tools/Package-ManualMapBundle.ps1 [-Force]
   ```

   The manifest at `tools/manualmap_bundle_manifest.json` controls which files are included. Override with `-ManifestPath` if needed.
3. Confirm the bundle SHA256 printed by the script and ensure it lives in `meshcentral-plugin/manualmap/assets/manualmap-bundle.zip`.
4. (Optional) Copy `meshcentral-plugin/manualmap/settings.example.json` to `settings.json` and adjust:
   - `"assetFile"` if you used a different archive name.
   - `"deployDir"` to change the remote installation directory.
   - `"runAsUser"` (`0` = agent service, `1` = interactive if available, `2` = interactive only).
   - `"cleanupOnUndeploy"` to keep files after an undeploy.
   - `"postDeployCommand"` for any additional bootstrap command.

## Deploying the Plugin

1. Deploy the plugin with:

   ```powershell
   powershell.exe -ExecutionPolicy Bypass -File tools/Deploy-ManualMapPlugin.ps1 -MeshCentralDataPath "C:\Path\To\meshcentral-data" [-RestartService]
   ```

   Use `-BackupExisting:$false` to skip automatic backups or `-PreserveSettings:$false` if you do not want to reuse a previous `settings.json`.
2. Restart MeshCentral if you did not supply `-RestartService`.
3. Log in as a site administrator and open **My Server → Plugins**, then enable **ManualMap Deployer**.

MeshCentral will now expose the asset bundle under `/plugins/manualmap/assets/<filename>` (and the same path prefixed with the domain ID when using multi-tenant paths).

## Using the ManualMap Tab

1. Select a device in MeshCentral.
2. Open the **ManualMap** tab.
3. Review the bundle metadata panel (name / size / SHA256 / last updated) and adjust the target directory or **Force redeploy** toggle if you want to overwrite an existing installation.
4. Click **Deploy** to push the assets or **Undeploy** to remove them.
5. The Activity Log shows queuing, agent connectivity, and command output; use **Check Status** if you only need to confirm an agent is online.

## Troubleshooting

- **No asset bundle found**: verify the archive exists in `assets/` and matches the filename in `settings.json`.
- **Agents report “offline”**: the plugin uses live WebSocket sessions; ensure the agent is connected to MeshCentral and that the operator has remote command rights.
- **Download or hash mismatch**: confirm the MeshCentral server name is reachable from the agent, that HTTPS certificates are trusted, and rebuild the bundle if the SHA256 reported in the UI differs from the file on disk.

## Security Considerations

- The plugin executes privileged PowerShell via MeshCentral’s `runcommands` channel. Restrict access to trusted administrators only.
- Asset bundles are served from the MeshCentral server. Keep the directory private, distribute archives over TLS, and prefer signed or hashed bundles for auditing.
- Hash validation is enforced before extraction, but you should still rotate bundles regularly and monitor activity logs for anomalies.
